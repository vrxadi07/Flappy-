# Flappy Bird Game in JavaScript

A Pen created on CodePen.

Original URL: [https://codepen.io/asmrdev/pen/wvxGNPP](https://codepen.io/asmrdev/pen/wvxGNPP).

